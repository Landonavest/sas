<!doctype html>

<html lang="en">
  <head>
    <title>Globe Bank</title>
    <meta charset="utf-8">
  </head>

  <body>

    <h1>Globe Bank: Coming Soon</h1>

  </body>
</html>
